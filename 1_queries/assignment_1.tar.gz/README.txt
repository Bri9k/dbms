Please do:

source create_univ.sql
source insert_univ.sql
source queries_univ.sql

For university

source RailwayDDL.sql
source SampleRailwayData.sql
source railway_queries.sql

For raiway
